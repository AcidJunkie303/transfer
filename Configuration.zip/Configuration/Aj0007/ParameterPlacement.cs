namespace AcidJunkie.Analyzers.Configuration.Aj0007;

public enum ParameterPlacement
{
    First,
    Last
}
